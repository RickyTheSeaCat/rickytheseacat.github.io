function discoverClick(){

}

function categoriesClick(){

}

function settingsClick(){
	window.open(href="settings.html", "_self");
}